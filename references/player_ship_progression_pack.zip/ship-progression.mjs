// Pure progression logic. Phaser scenes supply the current game's base stats.
export const STORAGE_KEY = 'spaceShooter.playerShips.v1';

export const SHIPS = Object.freeze([
  { id: 1, name: 'Cadet',      hp: 1.00, speed: 1.00, dps: 1.00, interval: 1.00, guns: 1, angles: [0],                         upgrade: 'Starter gun' },
  { id: 2, name: 'Swift',      hp: 1.08, speed: 1.03, dps: 1.10, interval: 0.98, guns: 2, angles: [0, 0],                      upgrade: 'Paired guns' },
  { id: 3, name: 'Arrow',      hp: 1.15, speed: 1.06, dps: 1.20, interval: 0.96, guns: 3, angles: [-7, 0, 7],                 upgrade: 'Narrow fan' },
  { id: 4, name: 'Bulwark',    hp: 1.25, speed: 1.05, dps: 1.30, interval: 0.95, guns: 3, angles: [0, 0, 0],                  upgrade: 'Focused armor strike' },
  { id: 5, name: 'Talon',      hp: 1.34, speed: 1.09, dps: 1.40, interval: 0.93, guns: 4, angles: [-4, 0, 0, 4],              upgrade: 'Four-gun cluster' },
  { id: 6, name: 'Vanguard',   hp: 1.43, speed: 1.12, dps: 1.50, interval: 0.91, guns: 5, angles: [-8, -3, 0, 3, 8],          upgrade: 'Five-shot coverage' },
  { id: 7, name: 'Lancer',     hp: 1.51, speed: 1.14, dps: 1.60, interval: 0.90, guns: 5, angles: [-3, 0, 0, 0, 3],           upgrade: 'Focused five-shot burst' },
  { id: 8, name: 'Ghost',      hp: 1.59, speed: 1.16, dps: 1.70, interval: 0.88, guns: 6, angles: [-8, -4, 0, 0, 4, 8],       upgrade: 'Six-shot sweep' },
  { id: 9, name: 'Sovereign',  hp: 1.66, speed: 1.18, dps: 1.80, interval: 0.86, guns: 7, angles: [-9, -5, -2, 0, 2, 5, 9],   upgrade: 'Seven-shot control' },
  { id: 10,name: 'Apex',       hp: 1.72, speed: 1.20, dps: 1.90, interval: 0.85, guns: 8, angles: [-9, -6, -3, 0, 0, 3, 6, 9],upgrade: 'Maximum eight-shot array' },
]);

export function assetKey(id) {
  if (!Number.isInteger(id) || id < 1 || id > 10) throw new RangeError('Ship id must be 1..10');
  return `playerShip${String(id).padStart(2, '0')}`;
}

export function initialProgress() {
  return { version: 1, maxUnlocked: 1, equipped: 1, victory: false };
}

export function normalizeProgress(value) {
  const n = Number(value?.maxUnlocked);
  const maxUnlocked = Number.isInteger(n) ? Math.min(10, Math.max(1, n)) : 1;
  return {
    version: 1,
    maxUnlocked,
    equipped: maxUnlocked,
    victory: maxUnlocked === 10 && value?.victory === true,
  };
}

export function loadProgress(storage = globalThis.localStorage) {
  try {
    const raw = storage?.getItem(STORAGE_KEY);
    return raw ? normalizeProgress(JSON.parse(raw)) : initialProgress();
  } catch {
    return initialProgress();
  }
}

export function saveProgress(progress, storage = globalThis.localStorage) {
  const clean = normalizeProgress(progress);
  try {
    storage?.setItem(STORAGE_KEY, JSON.stringify(clean));
    return true;
  } catch {
    return false; // Continue the current run if browser storage is unavailable.
  }
}

// Call once after a unique boss death has been confirmed. Duplicate and out-of-order
// events leave the state unchanged, so a repeated collision callback cannot skip ships.
export function defeatBoss(progress, bossId) {
  const current = normalizeProgress(progress);
  if (!Number.isInteger(bossId) || bossId < 1 || bossId > 10) {
    return { progress: current, changed: false, reason: 'invalid-boss' };
  }
  if (current.victory) return { progress: current, changed: false, reason: 'already-victorious' };
  if (bossId !== current.maxUnlocked) {
    return { progress: current, changed: false, reason: 'duplicate-or-out-of-order' };
  }
  if (bossId === 10) {
    return { progress: { ...current, victory: true }, changed: true, reason: 'final-victory' };
  }
  const next = bossId + 1;
  return {
    progress: { version: 1, maxUnlocked: next, equipped: next, victory: false },
    changed: true,
    reason: 'ship-unlocked',
  };
}

// Base values must be read from the existing Ship 01 implementation. Bullet damage
// is per projectile; if every bullet hits, aggregate DPS scales by profile.dps.
export function resolveShipStats(id, base) {
  const profile = SHIPS[id - 1];
  if (!profile) throw new RangeError('Unknown ship');
  for (const key of ['maxHp', 'moveSpeed', 'bulletDamage', 'fireIntervalMs']) {
    if (!(Number.isFinite(base[key]) && base[key] > 0)) throw new TypeError(`Invalid base ${key}`);
  }
  return {
    maxHp: Math.round(base.maxHp * profile.hp),
    moveSpeed: base.moveSpeed * profile.speed,
    fireIntervalMs: Math.round(base.fireIntervalMs * profile.interval),
    gunCount: profile.guns,
    anglesDeg: [...profile.angles],
    bulletDamage: base.bulletDamage * profile.dps * profile.interval / profile.guns,
    targetDpsMultiplier: profile.dps,
  };
}
