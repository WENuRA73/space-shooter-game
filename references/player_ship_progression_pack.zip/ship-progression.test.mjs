import test from 'node:test';
import assert from 'node:assert/strict';
import { SHIPS, STORAGE_KEY, assetKey, initialProgress, normalizeProgress,
  loadProgress, saveProgress, defeatBoss, resolveShipStats } from './ship-progression.mjs';

test('ten unique sequential ships and matching firing angles', () => {
  assert.equal(SHIPS.length, 10);
  assert.equal(new Set(SHIPS.map(s => s.name)).size, 10);
  SHIPS.forEach((s, i) => {
    assert.equal(s.id, i + 1);
    assert.equal(s.guns, s.angles.length);
    assert.equal(assetKey(s.id), `playerShip${String(i + 1).padStart(2, '0')}`);
  });
});

test('boss 01 through 09 unlock and equip exactly the next ship', () => {
  let p = initialProgress();
  for (let boss = 1; boss <= 9; boss++) {
    const result = defeatBoss(p, boss);
    assert.equal(result.changed, true);
    assert.equal(result.reason, 'ship-unlocked');
    assert.equal(result.progress.maxUnlocked, boss + 1);
    assert.equal(result.progress.equipped, boss + 1);
    p = result.progress;
  }
  assert.equal(defeatBoss(p, 10).progress.victory, true);
  assert.equal(defeatBoss(p, 10).progress.maxUnlocked, 10);
});

test('duplicate and out-of-order boss events cannot skip an unlock', () => {
  const p = defeatBoss(initialProgress(), 1).progress;
  assert.equal(defeatBoss(p, 1).changed, false);
  assert.equal(defeatBoss(p, 4).changed, false);
  assert.equal(defeatBoss(initialProgress(), 10).changed, false);
});

test('storage reload, corruption, and blocked storage', () => {
  const values = new Map();
  const store = { getItem: k => values.get(k), setItem: (k, v) => values.set(k, v) };
  const p = defeatBoss(initialProgress(), 1).progress;
  assert.equal(saveProgress(p, store), true);
  assert.deepEqual(loadProgress(store), p);
  values.set(STORAGE_KEY, '{broken');
  assert.deepEqual(loadProgress(store), initialProgress());
  assert.equal(saveProgress(p, { setItem: () => { throw Error('disabled'); } }), false);
  assert.deepEqual(loadProgress({ getItem: () => { throw Error('disabled'); } }), initialProgress());
  assert.equal(normalizeProgress({ maxUnlocked: 999 }).maxUnlocked, 10);
});

test('base ship matches existing balance and target DPS stays proportional', () => {
  const base = { maxHp: 100, moveSpeed: 300, bulletDamage: 10, fireIntervalMs: 250 };
  const starter = resolveShipStats(1, base);
  assert.equal(starter.maxHp, base.maxHp);
  assert.equal(starter.moveSpeed, base.moveSpeed);
  assert.equal(starter.bulletDamage, base.bulletDamage);
  assert.equal(starter.fireIntervalMs, base.fireIntervalMs);
  for (const ship of SHIPS) {
    const s = resolveShipStats(ship.id, base);
    const actual = s.bulletDamage * s.gunCount * (base.fireIntervalMs / s.fireIntervalMs) / base.bulletDamage;
    assert.ok(Math.abs(actual - ship.dps) < 0.01);
  }
});
