# Scrolling space background for Phaser 3

Three separate original game art layers are supplied. All are 1024 × 4096 RGBA PNGs with pixel-matched top and bottom edges for a continuous vertical loop. The second half mirrors the first vertically so both repeat joins stay clean.

| File | Purpose | Transparency | Suggested scroll rate |
|---|---|---|---:|
| `space_background_stars.png` | dark, distant starfield | opaque | 12 texture px/s |
| `space_background_nebula.png` | violet and cyan gas | transparent | 22 texture px/s |
| `space_background_dust.png` | sparse near stars | transparent | 45 texture px/s |

`space_background_preview.jpg` is only a composite for visual review; do not use it as a game texture. Put the three PNGs in `public/assets/backgrounds/` or the current Phaser static-asset folder. They are artwork, not collidable world objects.

## Phaser integration example

Adapt scene and player variable names to the existing project. Keep the background fixed to the screen while scrolling each texture. Its vertical motion gives the ship visible travel even when the player remains near the bottom of the viewport. Horizontal ship movement adds a small parallax shift.

```js
// Scene.preload()
this.load.image('spaceStars', 'assets/backgrounds/space_background_stars.png');
this.load.image('spaceNebula', 'assets/backgrounds/space_background_nebula.png');
this.load.image('spaceDust', 'assets/backgrounds/space_background_dust.png');

// Scene.create(), before creating the player, enemies, or HUD.
const width = this.scale.width;
const height = this.scale.height;
const tileScale = width / 1024; // cover the screen width without stretching stars
this.spaceLayers = [
  this.add.tileSprite(0, 0, width, height, 'spaceStars').setOrigin(0).setDepth(-300),
  this.add.tileSprite(0, 0, width, height, 'spaceNebula').setOrigin(0).setDepth(-290),
  this.add.tileSprite(0, 0, width, height, 'spaceDust').setOrigin(0).setDepth(-280),
];
for (const layer of this.spaceLayers) {
  layer.setScrollFactor(0);
  layer.setTileScale(tileScale);
}
this.spaceLayers[1].setAlpha(0.5); // optional: keep bullets readable
this.spaceLayers[2].setAlpha(0.65);

// Scene.update(time, delta), after player movement is updated.
const dt = Math.min(delta, 50) / 1000; // cap a long frame after tab focus resumes
const rates = [12, 22, 45];
const xFactors = [0.015, 0.035, 0.07];
const playerOffsetX = this.player.x - this.scale.width / 2;
this.spaceLayers.forEach((layer, i) => {
  layer.tilePositionY -= rates[i] * dt; // reverse sign if your world travels downward
  layer.tilePositionX = -playerOffsetX * xFactors[i];
});
```

Create the layers once per scene, not once per frame. For resize, update each TileSprite's size to the new viewport dimensions and its tile scale to `newWidth / 1024`. If a scene already has a scrolling world or camera, use its existing travel delta instead of a second constant speed; retain the three relative rates so the layers move at different apparent depths. Pause these updates when gameplay pauses. Keep UI elements above the background and keep the player collision body separate from the art.

## Checks in the actual game

1. The three PNGs load independently; the nebula and dust retain transparent regions.
2. Play for longer than one full background repeat. No hard horizontal line or jump should appear.
3. The background moves visibly while the ship flies, and the near stars respond a little more to horizontal ship movement than distant stars.
4. Ship, enemies, bullets, and HUD remain readable on both bright and dark portions. Reduce overlay alpha if needed.
5. On pause, restart, resize, and scene transition, the layers behave like the existing world and are not duplicated.

The actual Phaser project was not available with this request, so this pack provides assets and implementation guidance rather than a verified in-project integration.
